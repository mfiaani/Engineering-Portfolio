// Student Name: Michael Fiaani, Student ID: 300014312

public class Plane3D {
    // constructor var
    private double a, b, c, d; 
    
    // constructor classes
    public Plane3D(Point3D p1, Point3D p2, Point3D p3) {
        
        // Using ax + by + cz = d equation to find the plane passing through the 3 points...
        // Calculating a,b,c found in references

        double a1 = p2.getX() - p1.getX();
        double b1 = p2.getY() - p1.getY();
        double c1 = p2.getZ() - p1.getZ();

        double a2 = p3.getX() - p1.getX();
        double b2 = p3.getY() - p1.getY();
        double c2 = p3.getZ() - p1.getZ();

        a = (b1*c2) - (b2*a1);
        b = (a2*c1) - (a1*c2);
        c = (a1*b2) - (b1*a2);
        d = -a*p1.getX() - b*p1.getY() - c*p1.getZ();
    }

    public Plane3D(double a, double b, double c, double d){
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    // get function (plane eq'n)
    public String getPlaneEqn() {
        return a+"x + "+b+"y + "+c+"z = "+d;
    }

    // get function: Distance from plane and point given
    public double getDistance(Point3D pt) {
        double UpperBound = Math.abs(a*pt.getX() + b*pt.getY() + c*pt.getZ());
        double LowerBound = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2) + Math.pow(c,2));
        return UpperBound/LowerBound;
    }
}
