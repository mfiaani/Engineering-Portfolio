// Student Name: Michael Fiaani, Student ID: 300014312

import java.util.*;

public class PlaneRANSAC{
    
    // init constructor var
    private PointCloud pc = new PointCloud();
    private double eps;

    public PlaneRANSAC(PointCloud pc) {
        this.pc = pc;
    }

    public void setEPS (double eps) {
        this.eps = eps;
    }

    public double getEps() {
        return this.eps;
    }

    public int getNumberOfIterations (double confidence, double percentageOfPointsOnPlane) {
        //using the equation k = log(1-C)/log(1-p^3)
        double p = percentageOfPointsOnPlane;
        double p_cubed = Math.pow(p, 3);
        int k = (int) (Math.log(1 - confidence) / Math.log(1-p_cubed));
        return k;
    }

    public void run (int numberOfIterations, String filename) {
        
        PointCloud pc = new PointCloud(filename); // allocate points to original pc
        
        String filename_original = filename.replace(".xyz", "_p0.xyz");
        pc.save(filename_original); // write original point cloud

        for (int i=1; i<4; i++) { // run RANSAC three times here
        
        int best_support = 0; // step 1
        
        Iterator<Point3D> iter = pc.iterator(); // necessary for step 4
        Iterator<Point3D> iter2 = pc.iterator(); // necessary for step 7

        // must reset after each iteration
        PointCloud DominantPlane_cl = new PointCloud(); 
        Plane3D dominant_plane = null;

            for (int j=0; j<numberOfIterations;j++) { //step6 repeat steps 2-5 with number of iterations calculated
            
                Point3D p1_rand = pc.getRandomPoint(); //step 2
                Point3D p2_rand = pc.getRandomPoint();
                Point3D p3_rand = pc.getRandomPoint();

                Plane3D plane_rand = new Plane3D(p1_rand, p2_rand, p3_rand); // step 3

                // step 4
                int current_support = 0;
                while (iter.hasNext()) {
                    Point3D iter_point = iter.next();
                    double plane_distance = plane_rand.getDistance(iter_point); 
                    
                    if (plane_distance < eps) {
                        current_support++;
                    }
                }

                // step 5
                if (current_support > best_support) {
                    best_support = current_support;
                    dominant_plane = plane_rand; //new dominant plane
                }
            }
            // step 7
            String filename_write = filename.replace(".xyz", "_p"+i+".xyz");
           
            while (iter2.hasNext()) {
                Point3D dom_point = iter2.next();
                double dominant_plane_distance = dominant_plane.getDistance(dom_point); 
                if (dominant_plane_distance < eps) {
                    DominantPlane_cl.addPoint(dom_point);
                    iter2.remove();
                }
            }

            DominantPlane_cl.save(filename_write);
            this.setEPS(eps*1.5); // increase epsilon for the next dominant plane
            
        }
        //System.out.println(pc);
    }
}
