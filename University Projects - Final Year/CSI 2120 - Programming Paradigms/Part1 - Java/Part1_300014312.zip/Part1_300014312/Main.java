// Student Name: Michael Fiaani, Student ID: 300014312

public class Main {
    public static void main(String[] args) {
        PointCloud pc1 = new PointCloud("PointCloud1.xyz");
        PointCloud pc2 = new PointCloud("PointCloud2.xyz");
        PointCloud pc3 = new PointCloud("PointCloud3.xyz");

        PlaneRANSAC run1 = new PlaneRANSAC(pc1);
        PlaneRANSAC run2 = new PlaneRANSAC(pc2);
        PlaneRANSAC run3 = new PlaneRANSAC(pc3);

        run1.setEPS(2);
        run2.setEPS(2);
        run3.setEPS(2);

        int iter1 = run1.getNumberOfIterations(.99, 0.5);
        int iter2 = run2.getNumberOfIterations(.99, 0.5);
        int iter3 = run3.getNumberOfIterations(.99, 0.5);
       
        run1.run(iter1, "PointCloud1.xyz");
        run2.run(iter2, "PointCloud2.xyz");
        run3.run(iter3, "PointCloud3.xyz");
        
        // Through trial and error, looks like eps=2, p=0.5 gave the best looking results, Thanks!
    }
}
