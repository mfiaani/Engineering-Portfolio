// Student Name: Michael Fiaani, Student ID: 300014312

import java.util.*;
import java.io.*;

public class PointCloud {
    // PointCloud constructor, reads .xyz files and writes all points in a list to read from

    private ArrayList<Point3D> point_cloud = new ArrayList<>();

    public PointCloud (String filename) {
        point_cloud = new ArrayList<>(); // init new point cloud
        File file = new File(filename); 
        // open scanner to read xyz file line by line
        try (Scanner sc = new Scanner(file)) {
            sc.nextLine(); // skips x y z line
            while (sc.hasNextLine()) { // iterate line by line through file
                String[] line = sc.nextLine().split("\\s"); // parse line, and split by each number
                Point3D pt = new Point3D(Double.parseDouble(line[0]), Double.parseDouble(line[1]), Double.parseDouble(line[2])); // converts string to double, creates Point and stores in point_cloud list
                point_cloud.add(pt); // adds to cloud iteratively
            }
            sc.close();
        } 
        
        catch (FileNotFoundException e) { 
                e.printStackTrace();
            }
        }

    public PointCloud() {
        point_cloud = new ArrayList<>(); //init new point cloud from scratch
    }

    public void addPoint(Point3D pt) {
        point_cloud.add(pt); // add a point to an existing point_cloud
    }

    public void removePoint(Point3D pt) {
        point_cloud.remove(pt);
    }

    public Point3D getRandomPoint() {
        int index = (int)(Math.random()*(point_cloud.size())); // takes a random number from 0 to 1, multiplies by arraylist size to make sure random number within range
        //System.out.println(index); // make sure index is randomized
        return point_cloud.get(index);
    }

    // check to see if write function works
    public Point3D getSpecificPoint() {
        return point_cloud.get(100);
    }

    public void save(String filename) { //reverse of read function above
        try { 
            PrintWriter writer = new PrintWriter(filename);
            writer.println("x    y    z"); //write first line 
            for (Point3D pt : point_cloud) {
                writer.println(pt.getX() + " " + pt.getY() + " " + pt.getZ()); 
            }
            writer.close();
        } 
        
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    Iterator<Point3D> iterator() {
        return point_cloud.iterator(); // returns the iterator for Arraylist
    }

}