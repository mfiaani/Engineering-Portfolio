// Student Name: Michael Fiaani
// Student ID: 300014312
// Preffered confidence = 0.99, PoP = 0.5, eps = 2

package main

import (
	"bufio"
	"fmt"
	"log"
	"math"
	"math/rand"
	"os"
	"strconv"
	"strings"
)

type Point3D struct {
	X float64
	Y float64
	Z float64
}

type Plane3D struct {
	A float64
	B float64
	C float64
	D float64
}

type Plane3DwSupport struct {
	Plane3D
	SupportSize int
}

// Read takes xyz file outputs array list
func ReadXYZ(filename string) []Point3D {
	inF, err := os.Open(filename) // open file
	var point_list []Point3D

	if err != nil {
		log.Fatal(err)
	}
	defer inF.Close() // close file when program executed

	// open sc
	sc := bufio.NewScanner(inF)

	// skips first line "xyz"
	for sc.Scan() {
		sc.Text()
		break
	}

	// scan xyz file line by line
	for sc.Scan() {
		point := sc.Text()
		fields := strings.Fields(point)           // splits line by whitespace and returns as array
		x, _ := strconv.ParseFloat(fields[0], 64) // converts str into float64
		y, _ := strconv.ParseFloat(fields[1], 64)
		z, _ := strconv.ParseFloat(fields[2], 64)
		point_list = append(point_list, Point3D{x, y, z}) // appends to array list
	}

	return point_list
}

// takes xyz point array and writes to file
func SaveXYZ(filename string, points []Point3D) {
	outF, err := os.Create(filename) // opens new file
	if err != nil {
		log.Fatal(err)
	}
	defer outF.Close()

	fmt.Fprintln(outF, "x	y	z")

	// write to file length of array list
	for _, point := range points {
		fmt.Fprintf(outF, "%f %f %f\n", point.X, point.Y, point.Z)
	}
}

// getDistance: returns distance between 2 points
func (p1 *Point3D) GetDistance(p2 *Point3D) float64 {
	dx := p1.X - p2.X
	dy := p1.Y - p2.Y
	dz := p1.Z - p2.Z
	return math.Sqrt(dx*dx + dy*dy + dz*dz)
}

// calculates plane of 3 points (via triplet)
func GetPlane(points []Point3D) Plane3D {
	p1, p2, p3 := points[0], points[1], points[2]

	// plane eq'n: ax + by + cz = d
	a1 := p2.X - p1.X
	b1 := p2.Y - p1.Y
	c1 := p2.Z - p1.Z

	a2 := p3.X - p1.X
	b2 := p3.Y - p1.Y
	c2 := p3.Z - p1.Z

	a := b1*c2 - b2*a1
	b := a2*c1 - a1*c2
	c := a1*b2 - b1*a2
	d := -a*p1.X - b*p1.Y - c*p1.Z

	return Plane3D{a, b, c, d} // return calculated values
}

// getPlaneDistance function
func GetPlaneDistance(plane Plane3D, point Point3D) float64 {
	UpperBound := math.Abs(plane.A*point.X + plane.B*point.Y + plane.C*point.Z)
	LowerBound := math.Sqrt(math.Pow(plane.A, 2) + math.Pow(plane.B, 2) + math.Pow(plane.C, 2))
	return UpperBound / LowerBound
}

func GetNumberOfIterations(confidence float64, percentageOfPointsOnPlane float64) int {
	return int(math.Ceil(math.Log(1-confidence) / math.Log(1-math.Pow(percentageOfPointsOnPlane, 3))))
}

// getSupport counts # of points within eps, returns support
func GetSupport(plane Plane3D, points []Point3D, eps float64) Plane3DwSupport {
	var currentSupport int
	for _, p := range points {
		plane_distance := GetPlaneDistance(plane, p)
		if plane_distance <= eps {
			currentSupport++
		}
	}
	return Plane3DwSupport{plane, currentSupport}
}

// getSupportingPoints counts points that are within the current support
func GetSupportingPoints(plane Plane3D, points []Point3D, eps float64) []Point3D {
	var supportingPoints []Point3D
	for _, p := range points {
		plane_distance := GetPlaneDistance(plane, p)
		if plane_distance <= eps {
			supportingPoints = append(supportingPoints, p)
		}
	}
	return supportingPoints
}

// removePlane calculates points outside of support (does the opposite of getSupportingPoints)
func RemovePlane(plane Plane3D, points []Point3D, eps float64) []Point3D {
	var remainingPoints []Point3D
	for _, p := range points {
		plane_distance := GetPlaneDistance(plane, p)
		if plane_distance > eps {
			remainingPoints = append(remainingPoints, p)
		}
	}
	return remainingPoints
}

func main() {
	// Step 1
	filename := os.Args[1]
	points_list := ReadXYZ(filename)

	// Step 2
	bestSupport := Plane3DwSupport{}

	// Step 3
	confidence, _ := strconv.ParseFloat(os.Args[2], 64)
	percentage, _ := strconv.ParseFloat(os.Args[3], 64)
	eps, _ := strconv.ParseFloat(os.Args[4], 64)
	iterations := GetNumberOfIterations(confidence, percentage)

	// Step 4
	// Init pipeline channels
	randChan := make(chan Point3D)            // randGen channel
	tripChan := make(chan [3]Point3D)         // triples channel
	takeNChan := make(chan [3]Point3D)        // takeN channel
	planeEstChan := make(chan Plane3D)        // plane est channel
	supportChan := make(chan Plane3DwSupport) // support finder chan
	//fanInChan := make(chan Plane3DwSupport)
	//dominantPlaneChan := make(chan Plane3DwSupport)
	doneChan := make(chan bool) // stops pipeline when takeN closes

	// run PlaneRANSAC three times here
	for run := 1; run < 4; run++ {
		// Random Point Generator -> Point3D
		go func() {
			defer close(randChan)
			for {
				randGen := rand.Intn(len(points_list)) // creates random index within range of XYZ file
				randChan <- points_list[randGen]       // Stores into channel (randChan)
			}
		}()

		// Triplet Point Generator -> [3]Point3D
		go func() {
			defer close(tripChan)
			var triplet [3]Point3D
			for randPoint := range randChan { // where randChan is the input (random point gen)
				triplet[0], triplet[1], triplet[2] = triplet[1], triplet[2], randPoint // random point cycles through triplet here
				tripChan <- triplet                                                    // Store into output channel (tripChan)
			}
		}()

		// TakeN -> [3]Point3D
		go func() {
			defer close(takeNChan)
			for i := 0; i < iterations; i++ {
				for triplet := range tripChan { // iterates through tripChan and returns triplets until...
					takeNChan <- triplet
				}
			}
			doneChan <- true // iterations are complete, closes pipeline here
		}()

		// Plane estimator -> Plane3D
		go func() {
			defer close(planeEstChan)
			for triplet := range takeNChan { // where input is takeNChan
				plane := GetPlane(triplet[:])
				planeEstChan <- plane // plane stored here
			}
		}()

		// Supporting point finder -> Plane3DwSupport
		go func() {
			defer close(supportChan)
			for plane := range planeEstChan {
				support := GetSupport(plane, points_list, eps)
				supportChan <- support // support stored here
			}
		}()

		// Dominant Plane -> Plane3DwSupport
		go func() {
			for support := range supportChan {
				if support.SupportSize > bestSupport.SupportSize {
					bestSupport = support
				}
			}
		}()

		// wait for pipeline to finish
		<-doneChan

		// Step 5
		supportingPoints := GetSupportingPoints(bestSupport.Plane3D, points_list, eps)
		supportFilename := strings.TrimSuffix(filename, ".xyz") + "_p" + strconv.Itoa(run) + ".xyz"
		SaveXYZ(supportFilename, supportingPoints)

		// Step 6
		originalPoints := RemovePlane(bestSupport.Plane3D, points_list, eps)
		originalFilename := strings.TrimSuffix(filename, ".xyz") + "_p0.xyz"
		SaveXYZ(originalFilename, originalPoints)
	}
}
