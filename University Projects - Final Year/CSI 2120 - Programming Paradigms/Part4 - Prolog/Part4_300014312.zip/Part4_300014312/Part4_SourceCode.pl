% Student Name: Michael Fiaani
% Student ID: 300014312

% Predicate that reads points and stores as a list
read_xyz_file(File, Points) :-
    open(File, read, Stream),
read_xyz_points(Stream,Points),
    close(Stream).
read_xyz_points(Stream, []) :-
    at_end_of_stream(Stream).
read_xyz_points(Stream, [Point|Points]) :-
    \+ at_end_of_stream(Stream),
read_line_to_string(Stream,L), split_string(L, "\t", "\s\t\n",XYZ), convert_to_float(XYZ,Point), read_xyz_points(Stream, Points).
convert_to_float([],[]).
convert_to_float([H|T],[HH|TT]) :-
    atom_number(H, HH),
    convert_to_float(T,TT). 

% random3points takes in a list of points (Points) and a list of 3 points (Point3)
% Points list is randomly ordered, then Point1, Point2 and Point3 assigns the first 3 points of the random points list
random3points(Points, Point3) :-
    random_permutation(Points, Random),
    Point3 = [[X1, Y1, Z1], [X2, Y2, Z2], [X3, Y3, Z3]],
    [Point1, Point2, Point3 | _] = Random,
    Point1 = [X1, Y1, Z1],
    Point2 = [X2, Y2, Z2],
    Point3 = [X3, Y3, Z3].

% plane takes in a points list from a text file, and 3 random points are selected
% coefficients are calculated using plane equation
plane(Points, [A,B,C,D]) :-
    random3points(Points, [[X1, Y1, Z1], [X2, Y2, Z2], [X3, Y3, Z3]]
    A is Y1*(Z2 - Z3) + Y2*(Z3 - Z1) + Y3*(Z1 - Z2),
    B is Z1*(X2 - X3) + Z2*(X3 - X1) + Z3*(X1 - X2),
    C is X1*(Y2 - Y3) + X2*(Y3 - Y1) + X3*(Y1 - Y2),
    D is -X1*(Y2*Z3 - Y3*Z2) - X2*(Y3*Z1 - Y1*Z3) - X3*(Y1*Z2 - Y2*Z1).

% support takes in the list of points from text file, and generates 3 random points 
% plane calculates coefficients from 3 points, then finds all points with a distance within eps 
% returns true if N==3, which is the number of points generated

support([A,B,C,D], Points, Eps, N) :-
    random3points(Points, Point3),
    plane(Point3, [A,B,C,D]),
    findall(P, (member(P, Points), D =< Eps), Support),
    length(Support, N),
    N >= 3.

% ransac-number-of-iterations takes in confidence, percentage of points and calculates number of iterations
ransac-number-of-iterations(Confidence, Percentage, N) :-
    N is ceiling(log(1 - Confidence) / log(1 - Percentage^3)).

% random3points test cases, returns true if xyz of Points 1,2,3 is a part of the original points list (Points)
test(random3points, 1) :-
    read_xyz_file('./Point_Cloud_1_No_Road_Reduced.xyz', Points),
    random3points(Points, Point3),
    member([X1, Y1, Z1], Points),
    member([X2, Y2, Z2], Points),
    member([X3, Y3, Z3], Points).

test(random3points, 2) :-
    read_xyz_file('./Point_Cloud_2_No_Road_Reduced.xyz', Points),
    random3points(Points, Point3),
    member([X1, Y1, Z1], Points),
    member([X2, Y2, Z2], Points),
    member([X3, Y3, Z3], Points).

test(random3points, 3) :-
    read_xyz_file('./Point_Cloud_3_No_Road_Reduced.xyz', Points),
    random3points(Points, Point3),
    member([X1, Y1, Z1], Points),
    member([X2, Y2, Z2], Points),
    member([X3, Y3, Z3], Points).